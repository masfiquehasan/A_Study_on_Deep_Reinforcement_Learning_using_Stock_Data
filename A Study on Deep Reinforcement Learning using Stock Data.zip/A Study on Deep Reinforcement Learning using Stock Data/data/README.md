# Data

Price data is **not** stored in this repository. The code needs a CSV with a `Close` (or `Adj Close`) column of daily prices.

    pip install yfinance
    python scripts/download_prices.py --ticker <SYMBOL> --start <YYYY-MM-DD> --end <YYYY-MM-DD>
    python src/stock_drl.py --csv data/prices.csv --seeds 5 --out_dir results

