"""Deep reinforcement learning for stock trading: DQN, Double DQN, Dueling Double DQN.

Reconstruction of the experiment in "A Study on Deep Reinforcement Learning using Stock Data".
Pure NumPy (no TensorFlow / PyTorch needed): small multi-layer perceptrons with manual
back-propagation and the Adam optimiser.

  * Agent: buys / sells / holds ONE asset (all-in, fractional shares), transaction cost 0.1 %.
  * State: the last WINDOW daily log-returns (scaled) and the current position (0 = cash, 1 = holding).
  * Actions: 0 = hold, 1 = buy, 2 = sell.   Reward: log change of the portfolio value.
  * Training: EPISODES episodes of EPISODE_LEN steps (50 x 445 = 22,250 steps, as in the paper's table).
  * Algorithms: DQN, Double DQN, Dueling Double DQN (same seeds, same data, same hyper-parameters).

Usage:
  python stock_drl.py --csv prices.csv                  # CSV with a Close (or Adj Close) column
  python stock_drl.py --synthetic                       # fake prices, only to test that the code runs
Outputs (folder --out_dir): results_table.csv/.tex, training_curves.png, comparison.png,
test_results.csv, run_config.json
"""
import argparse, json, os, platform, time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ACTIONS = 3  # hold, buy, sell


# --------------------------------------------------------------------------- data
def load_prices(a):
    if a.synthetic:
        rng = np.random.default_rng(123)
        n = 2500
        drift = np.where((np.arange(n) // 250) % 2 == 0, 0.0006, -0.0003)
        r = drift + 0.012 * rng.standard_normal(n)
        return 100 * np.exp(np.cumsum(r))
    df = pd.read_csv(a.csv)
    cols = {c.lower().strip(): c for c in df.columns}
    for key in ("adj close", "close", "adj_close"):
        if key in cols:
            p = df[cols[key]].astype(float).dropna().values
            return p
    raise SystemExit(f"No Close column found in {a.csv}: columns = {list(df.columns)}")


# --------------------------------------------------------------------------- environment
class TradingEnv:
    def __init__(self, prices, window=10, cost=0.001, start_value=10_000.0):
        self.p = np.asarray(prices, float)
        self.ret = np.diff(np.log(self.p), prepend=np.log(self.p[0]))  # ret[i] = log(p[i]/p[i-1])
        self.window, self.cost, self.v0 = window, cost, start_value

    def reset(self, start, length):
        self.i, self.end = start, start + length
        self.pos, self.value, self.trades = 0, self.v0, 0
        return self._state()

    def _state(self):
        w = self.ret[self.i - self.window + 1: self.i + 1] * 20.0     # scaled returns
        return np.append(np.clip(w, -3, 3), float(self.pos)).astype(np.float32)

    def step(self, action):
        old = self.value
        if action == 1 and self.pos == 0:      # buy
            self.pos, self.value, self.trades = 1, self.value * (1 - self.cost), self.trades + 1
        elif action == 2 and self.pos == 1:    # sell
            self.pos, self.value, self.trades = 0, self.value * (1 - self.cost), self.trades + 1
        gain = self.p[self.i + 1] / self.p[self.i]
        if self.pos == 1:
            self.value *= gain
        reward = float(np.log(self.value / old))
        self.i += 1
        done = self.i >= self.end
        return self._state(), reward, done


# --------------------------------------------------------------------------- neural network
class QNet:
    """MLP: d -> h -> h -> (A actions)  or dueling: trunk d -> h -> h, heads V(1) and A(actions)."""

    def __init__(self, d, h, dueling, rng):
        he = lambda i, o: (rng.standard_normal((i, o)) * np.sqrt(2.0 / i)).astype(np.float32)
        self.dueling = dueling
        self.P = {"W1": he(d, h), "b1": np.zeros(h, np.float32), "W2": he(h, h), "b2": np.zeros(h, np.float32)}
        if dueling:
            self.P.update(Wv=he(h, 1), bv=np.zeros(1, np.float32), Wa=he(h, ACTIONS), ba=np.zeros(ACTIONS, np.float32))
        else:
            self.P.update(W3=he(h, ACTIONS), b3=np.zeros(ACTIONS, np.float32))
        self.m = {k: np.zeros_like(v) for k, v in self.P.items()}
        self.v = {k: np.zeros_like(v) for k, v in self.P.items()}
        self.t = 0

    def forward(self, x, cache=False):
        P = self.P
        z1 = x @ P["W1"] + P["b1"]; h1 = np.maximum(z1, 0)
        z2 = h1 @ P["W2"] + P["b2"]; h2 = np.maximum(z2, 0)
        if self.dueling:
            V = h2 @ P["Wv"] + P["bv"]
            A = h2 @ P["Wa"] + P["ba"]
            Q = V + A - A.mean(axis=1, keepdims=True)
        else:
            Q = h2 @ P["W3"] + P["b3"]
        return (Q, (x, z1, h1, z2, h2)) if cache else Q

    def backward(self, dQ, c):
        x, z1, h1, z2, h2 = c
        P, g = self.P, {}
        if self.dueling:
            dV = dQ.sum(axis=1, keepdims=True)
            dA = dQ - dQ.mean(axis=1, keepdims=True)
            g["Wv"], g["bv"] = h2.T @ dV, dV.sum(0)
            g["Wa"], g["ba"] = h2.T @ dA, dA.sum(0)
            dh2 = dV @ P["Wv"].T + dA @ P["Wa"].T
        else:
            g["W3"], g["b3"] = h2.T @ dQ, dQ.sum(0)
            dh2 = dQ @ P["W3"].T
        dz2 = dh2 * (z2 > 0)
        g["W2"], g["b2"] = h1.T @ dz2, dz2.sum(0)
        dz1 = (dz2 @ P["W2"].T) * (z1 > 0)
        g["W1"], g["b1"] = x.T @ dz1, dz1.sum(0)
        return g

    def adam(self, g, lr, clip=10.0, b1=0.9, b2=0.999, eps=1e-8):
        norm = np.sqrt(sum((v ** 2).sum() for v in g.values()))
        s = min(1.0, clip / (norm + 1e-12))
        self.t += 1
        for k, grad in g.items():
            grad = grad * s
            self.m[k] = b1 * self.m[k] + (1 - b1) * grad
            self.v[k] = b2 * self.v[k] + (1 - b2) * grad ** 2
            mh, vh = self.m[k] / (1 - b1 ** self.t), self.v[k] / (1 - b2 ** self.t)
            self.P[k] = self.P[k] - lr * mh / (np.sqrt(vh) + eps)

    def copy_from(self, other):
        self.P = {k: v.copy() for k, v in other.P.items()}


# --------------------------------------------------------------------------- agent
ALGOS = {"DQN": dict(dueling=False, double=False),
         "Double DQN": dict(dueling=False, double=True),
         "Dueling Double DQN": dict(dueling=True, double=True)}


def train_one(name, prices, a, seed):
    cfg = ALGOS[name]
    rng = np.random.default_rng(seed)
    env = TradingEnv(prices, a.window, a.cost)
    d = a.window + 1
    online = QNet(d, a.hidden, cfg["dueling"], rng); target = QNet(d, a.hidden, cfg["dueling"], rng); target.copy_from(online)
    cap = a.buffer
    S = np.zeros((cap, d), np.float32); S2 = np.zeros((cap, d), np.float32)
    Ac = np.zeros(cap, np.int64); R = np.zeros(cap, np.float32); D = np.zeros(cap, np.float32)
    n = ptr = step = 0
    total_steps = a.episodes * a.episode_len
    eps_decay_steps = 0.6 * total_steps
    log = []
    for ep in range(a.episodes):
        start = int(rng.integers(a.window, len(prices) - a.episode_len - 1))
        s = env.reset(start, a.episode_len); ep_r = 0.0
        for _ in range(a.episode_len):
            eps = max(a.eps_end, 1.0 - (1.0 - a.eps_end) * step / eps_decay_steps)
            act = int(rng.integers(ACTIONS)) if rng.random() < eps else int(np.argmax(online.forward(s[None])[0]))
            s2, r, done = env.step(act)
            S[ptr], Ac[ptr], R[ptr], S2[ptr], D[ptr] = s, act, r, s2, float(done)
            ptr = (ptr + 1) % cap; n = min(n + 1, cap); step += 1; ep_r += r; s = s2
            if n >= a.warmup:
                idx = rng.integers(0, n, a.batch)
                Qn_t = target.forward(S2[idx])
                if cfg["double"]:
                    best = np.argmax(online.forward(S2[idx]), axis=1)          # select with online net ...
                    nxt = Qn_t[np.arange(a.batch), best]                       # ... evaluate with target net
                else:
                    nxt = Qn_t.max(axis=1)
                y = R[idx] + a.gamma * (1 - D[idx]) * nxt
                Q, cache = online.forward(S[idx], cache=True)
                dQ = np.zeros_like(Q)
                dQ[np.arange(a.batch), Ac[idx]] = 2.0 * (Q[np.arange(a.batch), Ac[idx]] - y) / a.batch   # MSE loss
                online.adam(online.backward(dQ, cache), a.lr)
            if step % a.target_sync == 0:
                target.copy_from(online)
            if done:
                break
        log.append(dict(episode=ep + 1, steps=env.i - start, reward=ep_r, profit=env.value - env.v0, trades=env.trades))
    return online, pd.DataFrame(log)


def greedy_eval(net, prices, a, start, end):
    env = TradingEnv(prices, a.window, a.cost)
    s = env.reset(start, end - start - 1); tot = 0.0
    while True:
        s, r, done = env.step(int(np.argmax(net.forward(s[None])[0]))); tot += r
        if done: break
    return dict(ret_pct=100 * (env.value / env.v0 - 1), trades=env.trades)


# --------------------------------------------------------------------------- main
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--csv"); p.add_argument("--synthetic", action="store_true")
    p.add_argument("--out_dir", default="results")
    p.add_argument("--episodes", type=int, default=50); p.add_argument("--episode_len", type=int, default=445)
    p.add_argument("--seeds", type=int, default=3, help="independent runs per algorithm (report mean and std)")
    p.add_argument("--window", type=int, default=10); p.add_argument("--hidden", type=int, default=64)
    p.add_argument("--gamma", type=float, default=0.99); p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--batch", type=int, default=32); p.add_argument("--buffer", type=int, default=20000)
    p.add_argument("--warmup", type=int, default=500); p.add_argument("--target_sync", type=int, default=200)
    p.add_argument("--eps_end", type=float, default=0.05); p.add_argument("--cost", type=float, default=0.001)
    p.add_argument("--train_frac", type=float, default=0.8)
    a = p.parse_args()
    if not (a.csv or a.synthetic): p.error("give --csv or --synthetic")
    os.makedirs(a.out_dir, exist_ok=True)
    prices = load_prices(a)
    split = int(len(prices) * a.train_frac)
    train_p, test_start = prices[:split], split
    if len(train_p) < a.episode_len + a.window + 2:
        raise SystemExit(f"Need at least {a.episode_len + a.window + 2} training prices, got {len(train_p)}.")
    print(f"{len(prices)} prices: {split} for training, {len(prices) - split} held out for testing")

    rows, curves, tests = [], {}, []
    bh = 100 * (prices[-1] / prices[test_start] - 1)
    for name in ALGOS:
        logs, t_res = [], []
        for sd in range(a.seeds):
            t0 = time.time()
            net, log = train_one(name, train_p, a, seed=1000 + sd)
            logs.append(log)
            t_res.append(greedy_eval(net, prices, a, test_start, len(prices) - 1))
            print(f"{name:20s} seed {sd}: total reward {log.reward.sum():8.3f}  avg profit {log.profit.mean():10.1f}  "
                  f"test return {t_res[-1]['ret_pct']:7.2f}%  ({time.time() - t0:.0f} s)")
        L = pd.concat(logs)
        per_seed = lambda f: np.array([f(l) for l in logs])
        rows.append({"Algorithm": name, "Episodes": a.episodes, "Total Steps": int(logs[0].steps.sum()),
                     "Total Reward": per_seed(lambda l: l.reward.sum()).mean(), "Total Reward (std)": per_seed(lambda l: l.reward.sum()).std(),
                     "Average Profit": per_seed(lambda l: l.profit.mean()).mean(), "Average Profit (std)": per_seed(lambda l: l.profit.mean()).std(),
                     "Average Trades per Episode": per_seed(lambda l: l.trades.mean()).mean()})
        curves[name] = np.mean([l.reward.values for l in logs], axis=0)
        tests.append({"Algorithm": name, "Test return % (mean)": np.mean([t["ret_pct"] for t in t_res]),
                      "Test return % (std)": np.std([t["ret_pct"] for t in t_res]),
                      "Trades (mean)": np.mean([t["trades"] for t in t_res])})
    tests.append({"Algorithm": "Buy and hold", "Test return % (mean)": bh, "Test return % (std)": 0.0, "Trades (mean)": 1})

    res, tst = pd.DataFrame(rows), pd.DataFrame(tests)
    res.round(3).to_csv(os.path.join(a.out_dir, "results_table.csv"), index=False)
    tst.round(3).to_csv(os.path.join(a.out_dir, "test_results.csv"), index=False)
    with open(os.path.join(a.out_dir, "results_table.tex"), "w") as f:
        f.write("\\begin{tabular}{lrrrrr}\n\\hline\nAlgorithm & Episodes & Total Steps & Total Reward & Average Profit & Avg. Trades / Episode \\\\\n\\hline\n")
        for _, r in res.iterrows():
            f.write(f"{r['Algorithm']} & {int(r['Episodes'])} & {int(r['Total Steps']):,} & {r['Total Reward']:.1f} & {r['Average Profit']:.1f} & {r['Average Trades per Episode']:.2f} \\\\\n")
        f.write("\\hline\n\\end{tabular}\n")
    print("\nTraining-phase results (mean over seeds)\n", res.round(2).to_string(index=False))
    print("\nHeld-out test period (greedy policy)\n", tst.round(2).to_string(index=False))

    fig, ax = plt.subplots(figsize=(6, 3.6))
    for name, c in curves.items():
        k = max(1, len(c) // 10); sm = np.convolve(c, np.ones(k) / k, mode="valid")
        ax.plot(np.arange(len(sm)) + k, sm, label=name)
    ax.set(xlabel="Episode", ylabel=f"Episode reward (moving average)", title="Training reward per episode"); ax.legend(); fig.tight_layout()
    fig.savefig(os.path.join(a.out_dir, "training_curves.png"), dpi=200); plt.close(fig)
    fig, ax = plt.subplots(figsize=(5.5, 3.6))
    ax.bar(res["Algorithm"], res["Total Reward"], yerr=res["Total Reward (std)"], color=["#6a8caf", "#c08a5c", "#6aa06a"], capsize=4)
    ax.axhline(0, color="k", lw=0.8); ax.set(ylabel="Total reward (50 episodes)", title="Result comparison"); fig.tight_layout()
    fig.savefig(os.path.join(a.out_dir, "comparison.png"), dpi=200); plt.close(fig)
    json.dump(dict(vars(a), numpy=np.__version__, python=platform.python_version(), platform=platform.platform(),
                   n_prices=int(len(prices))), open(os.path.join(a.out_dir, "run_config.json"), "w"), indent=2)
    print("\nSaved to", a.out_dir)


if __name__ == "__main__":
    main()
