"""Download daily prices for one ticker into data/prices.csv (needs: pip install yfinance).

    python scripts/download_prices.py --ticker <SYMBOL> --start 2010-01-01 --end 2022-12-31

Use the ticker(s) and dates you actually used for the study. Yahoo Finance data is for personal/research use under
its own terms and is not stored in this repository.
"""
import argparse, os

ap = argparse.ArgumentParser()
ap.add_argument("--ticker", required=True)
ap.add_argument("--start", required=True)
ap.add_argument("--end", required=True)
a = ap.parse_args()
try:
    import yfinance as yf
except ImportError:
    raise SystemExit("install yfinance first: pip install yfinance")
df = yf.download(a.ticker, start=a.start, end=a.end, auto_adjust=False, progress=False)
if df.empty:
    raise SystemExit("no data returned for " + a.ticker)
if hasattr(df.columns, "levels"):          # newer yfinance returns multi-level columns
    df.columns = [c[0] for c in df.columns]
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "prices.csv")
df.reset_index().to_csv(out, index=False)
print("saved", os.path.abspath(out), len(df), "rows")
