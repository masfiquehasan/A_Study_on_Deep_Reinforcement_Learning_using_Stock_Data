import os, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def test_gradient_check():
    r = subprocess.run([sys.executable, os.path.join(ROOT, "tests", "gradient_check.py")], capture_output=True, text=True, timeout=300)
    assert r.returncode == 0, r.stdout + r.stderr
    assert "gradient check OK" in r.stdout


def test_synthetic_run(tmp_path):
    r = subprocess.run([sys.executable, os.path.join(ROOT, "src", "stock_drl.py"), "--synthetic", "--episodes", "2",
                        "--episode_len", "100", "--seeds", "1", "--out_dir", str(tmp_path)],
                       capture_output=True, text=True, timeout=600)
    assert r.returncode == 0, r.stderr[-2000:]
    assert (tmp_path / "results_table.csv").exists()
