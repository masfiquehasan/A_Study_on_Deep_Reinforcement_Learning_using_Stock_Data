"""Numerical gradient check of the hand-written back-propagation (standard and dueling nets)."""
import numpy as np
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from stock_drl import QNet
rng = np.random.default_rng(0)
for dueling in (False, True):
    net = QNet(11, 16, dueling, rng)
    for k in net.P: net.P[k] = net.P[k].astype(np.float64)
    x = rng.standard_normal((5, 11)); act = rng.integers(0, 3, 5); y = rng.standard_normal(5)
    def loss():
        Q = net.forward(x); return np.mean((Q[np.arange(5), act] - y) ** 2)
    Q, c = net.forward(x, cache=True)
    dQ = np.zeros_like(Q); dQ[np.arange(5), act] = 2 * (Q[np.arange(5), act] - y) / 5
    g = net.backward(dQ, c)
    worst = 0
    for k in net.P:
        flat = net.P[k].reshape(-1)
        for j in rng.choice(flat.size, min(6, flat.size), replace=False):
            old = flat[j]; h = 1e-6
            flat[j] = old + h; lp = loss(); flat[j] = old - h; lm = loss(); flat[j] = old
            num = (lp - lm) / (2 * h); ana = g[k].reshape(-1)[j]
            worst = max(worst, abs(num - ana) / (abs(num) + abs(ana) + 1e-8))
    print("dueling" if dueling else "standard", "max relative gradient error: %.2e" % worst)
    assert worst < 1e-4
print("gradient check OK")
